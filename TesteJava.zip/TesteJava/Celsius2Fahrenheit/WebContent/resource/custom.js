function Esconder() {
	var e = document.getElementById("temp");
	var result = e.options[e.selectedIndex].value;

	if (result == "Celsius2Fahrenheit") {
		console.log("Celsius para Fahrenheit");
		document.getElementById("celsius").style.display = "block";
		document.getElementById("celsius").value = "";
		document.getElementById("Fahrenheit").style.display = "none";
		document.getElementById("Fahrenheit").value = "";
	} else {
		console.log("Fahrenheit para Celsius ");
		document.getElementById("Fahrenheit").style.display = "block";
		document.getElementById("Fahrenheit").value = "";
		document.getElementById("celsius").style.display = "none";
		document.getElementById("celsius").value = "";
	}
};
