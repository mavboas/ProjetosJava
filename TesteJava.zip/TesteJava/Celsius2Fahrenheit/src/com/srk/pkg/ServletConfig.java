package com.srk.pkg;

import java.io.IOException;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletConfig
 */
@WebServlet("/converter")
public class ServletConfig extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// Coleta Variavel

		String fahrenheit1 = request.getParameter("fahrenheit");

		if (fahrenheit1 != "") {
			Float fahrenheit = Float.parseFloat(request.getParameter("fahrenheit"));
			Float celsius = ((fahrenheit - 32) * 5) / 9;

			response.setContentType(
					"page language=\"java\" contentType=\"text/html; charset=ISO-8859-1\" pageEncoding=\"ISO-8859-1\"");
			try (PrintWriter out = response.getWriter()) {
				out.println("<!doctype html>");
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Resultado da Convers�o</title>");
				out.println("<link rel=\"stylesheet\" href=\"resource/bootstrap.min.css\"/>");
				out.println("</head>");
				out.println("<body>");
				out.println("<div class=\"container\">");
				out.println("<h1>Resultado da Convers�o</h1>");
				out.println("<div class=\"card\">");
				out.println("<div class=\"card-body\">");
				out.printf("<h1>" + fahrenheit + "�F � igual � " + celsius + "�C </h1>");
				out.println("</div>");
				out.println("</div>");
				out.println("</div>");
				out.println("</body>");
				out.println("</html>");
			}

		} else {
			Float celsius = Float.parseFloat(request.getParameter("celsius"));
			Float fahrenheit = ((celsius * 9) / 5) + 32;

			response.setContentType(
					"page language=\"java\" contentType=\"text/html; charset=ISO-8859-1\" pageEncoding=\"ISO-8859-1\"");
			try (PrintWriter out = response.getWriter()) {
				out.println("<!doctype html>");
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Resultado da Convers�o</title>");
				out.println("<link rel=\"stylesheet\" href=\"resource/bootstrap.min.css\"/>");
				out.println("</head>");
				out.println("<body>");
				out.println("<div class=\"container\">");
				out.println("<h1>Resultado da Convers�o</h1>");
				out.println("<div class=\"card\">");
				out.println("<div class=\"card-body\">");
				out.printf("<h1>" + celsius + "�C � igual � " + fahrenheit + "�F </h1>");
				out.println("</div>");
				out.println("</div>");
				out.println("</div>");
				out.println("</body>");
				out.println("</html>");
			}
		}

	}
	
}
